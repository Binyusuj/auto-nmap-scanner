import os
import argparse
import nmap
from datetime import datetime

def scan(targets, scan_type="quick"):
    nm = nmap.PortScanner()
    scan_options = {
        "ping": "-sn",
        "quick": "-T4 -F",
        "full": "-T4 -p-",
        "os": "-O"
    }

    print(f"[+] Scanning: {targets} with scan type: {scan_type}")
    nm.scan(hosts=targets, arguments=scan_options.get(scan_type, "-F"))

    report = []
    for host in nm.all_hosts():
        report.append(f"Host: {host}")
        if 'tcp' in nm[host]:
            for port in nm[host]['tcp']:
                state = nm[host]['tcp'][port]['state']
                name = nm[host]['tcp'][port]['name']
                report.append(f"  - {port}/tcp: {state} ({name})")
        report.append("")

    filename = f"results/scan_report_{datetime.now().strftime('%Y-%m-%d')}.txt"
    os.makedirs("results", exist_ok=True)
    with open(filename, "w") as f:
        f.write("\n".join(report))
    print(f"[+] Report saved to {filename}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--targets", required=True, help="Target IP or CIDR (e.g., 192.168.1.0/24)")
    parser.add_argument("--type", default="quick", help="Scan type: ping, quick, full, os")
    args = parser.parse_args()

    scan(args.targets, args.type)
