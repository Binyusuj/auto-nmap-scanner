# 🔎 Auto Nmap Scanner

A Python-based automation tool for running Nmap scans on multiple hosts and storing results in a clean, structured format.

## 🚀 Features

- Automated host scanning using Nmap
- Save results to timestamped files
- Supports basic scan types (TCP, UDP, OS detection)
- Parses output for known services and vulnerabilities

## ⚙️ Requirements

- Python 3.x
- Nmap installed on your system
- `python-nmap` library

Install dependencies:

```bash
pip install -r requirements.txt
```

## 🛠️ Usage

```bash
python scanner.py --targets 192.168.1.0/24 --type full
```

Arguments:
- `--targets`: IP address or CIDR range
- `--type`: Scan type (`ping`, `quick`, `full`, `os`)

## 📁 Output

Scan results will be saved under the `/results/` folder with timestamped filenames.

## 🤖 Sample Output

```text
Host: 192.168.1.10
Ports:
  - 22/tcp: Open (SSH)
  - 80/tcp: Open (HTTP)
OS Guess: Linux 3.X
```

## 🔐 For Educational Use

> This tool is meant for ethical use only. Do not scan systems you don't own or have permission to test.
